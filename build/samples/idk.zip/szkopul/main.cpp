#include <iostream>
//#include <chrono>

using namespace std;

inline bool check(const string &word) {
    for (int i = 0; i < (int) word.size() - 1; i++) {
        if (word[i] == word[i + 1]) {
            return false;
        }
    }
    return true;
}

int counter = 0;
string output = "";

void genWordAndCheck2(string word, const int &desiredLength) {
    if (desiredLength == word.size()) {
        if (check(word)) {
            counter++;
            output += "\n" + word;
        }
    }
    else {
        genWordAndCheck2(word + 'a', desiredLength);
        genWordAndCheck2(word + 'b', desiredLength);
        genWordAndCheck2(word + 'c', desiredLength);
    }
}

int main() {
    int len;
    cin >> len;

    //std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();

    genWordAndCheck2("", len);
    //std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
    cout << counter;
    cout << output;
    //std::cout << "Time difference = " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count() << "[µs]" << std::endl;
    //std::cout << "Time difference = " << std::chrono::duration_cast<std::chrono::nanoseconds> (end - begin).count() << "[ns]" << std::endl;
    //std::cout << "Time difference = " << std::chrono::duration_cast<std::chrono::milliseconds> (end - begin).count() << "[ms]" << std::endl;
    return 0;
}