import tkinter as tk

window = tk.Tk()
window.geometry("300x300")
window.resizable(False, False)
label1 = tk.Label(window, text="label 1", bg="silver")
label1.place(x=0, y=20, width=50, height=35)

label2 = tk.Label(window, text="Label 2", bg="red")
label2.place(x=70, y=70, width=90, height=35)


movingLeft = False
movingUp = False
winY = 0
winX = 0
def move():
    global winX, movingLeft, winY, movingUp
    if not movingLeft:
        winX += 100
        if (winX + window.winfo_width() > window.winfo_screenwidth()):
            movingLeft = True
    else:
        winX -= 100
        if (winX < 0):
            movingLeft = False

    if not movingUp:
        winY += 100
        if (winY + window.winfo_height() > window.winfo_screenheight()):
            movingUp = True
    else:
        winY -= 100
        if (winY < 0):
            movingUp = False
    
    window.geometry(f"+{winX}+{winY}")
    window.after(500, move)

window.after(500, move)
window.mainloop()