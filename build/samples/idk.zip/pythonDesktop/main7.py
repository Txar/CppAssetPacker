import tkinter as tk
window = tk.Tk()
scrollbar = tk.Scrollbar(window)
textBox = tk.Text(window, height=6, width=30, padx=5, pady=5,
                font="Times 16 bold")
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

#scrollbarHorizontal = tk.Scrollbar(window, orient="horizontal")
#scrollbarHorizontal.pack(side=tk.BOTTOM, fill=tk.X)
#textBox.pack(side=tk.LEFT, fill=tk.BOTH)

textBox.pack(side=tk.LEFT, fill=tk.Y)
scrollbar.config(command=textBox.yview)
textBox.config(yscrollcommand = scrollbar.set)
textBox.insert(tk.END, "Hello World! \n Hello Again!")
print("Text data:", textBox.get(1.0, "end"))
window.mainloop()