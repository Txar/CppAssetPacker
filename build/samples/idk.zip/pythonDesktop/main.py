import tkinter as tk
from PIL import Image, ImageTk
import os

scriptDir = os.path.dirname(__file__)
os.chdir(scriptDir)
window = tk.Tk()
window.title("Application")

resize = Image.open("cat.png").resize((200, 200))
logo = ImageTk.PhotoImage(resize)
#logo = tk.PhotoImage(file="cat.png")

label1 = tk.Label(window,
    text="Hello World!",
    foreground = "white",
    background = "black",
    width = 20,
    height = 3,
    cursor = "dot",
    font = "Times 18 bold italic underline",
    anchor = tk.W,
    padx = 5,
    pady = 5
)
label1.pack()

label2 = tk.Label(window, text="Hello again!")
label2.pack()

label3 = tk.Label(window,
    text = "Hello World",
    image=logo,
    width=200,
    height=200,
    foreground="red",
    compound=tk.CENTER
)
label3.pack()

label3.config(text="Hello World! \n Hello again!")

count = 0
labelIncrement = tk.Label(window, text="0")
labelIncrement.pack()
def incrementButtonClicked():
    global count
    count += 1
    labelIncrement.config(text=str(count))

button = tk.Button(window, text="+1", command=incrementButtonClicked)
button.pack()
window.mainloop()