import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import sqlite3

class TaskManager:
    def __init__(self, root):
        self.root = root
        self.root.title("Menadżer Zadań")
        self.root.geometry("800x600")
        self.root.resizable(False, False)
        self.conn = sqlite3.connect("Tasks.db")
        self.cursor = self.conn.cursor()
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            status TEXT NOT NULL
            )
            """)
        self.conn.commit()
        self.create_widgets()
    def create_widgets(self):
        font = ("Arial", 12)

        def genLabel(title : str):
            return tk.Label(input_frame, text=title, font=font)

        input_frame = tk.Frame(self.root, padx=10, pady=10)
        input_frame.pack(fill=tk.X)
        genLabel("Tytuł Zadania").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.title_entry = tk.Entry(input_frame, width=50, font=font)
        self.title_entry.grid(row=0, column=1, pady=5, padx=10)

        genLabel("Opis zadania:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.description_entry = tk.Entry(input_frame, width=50, font=font)
        self.description_entry.grid(row=1, column=1, pady=5, padx=10)

        genLabel("Status:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.status_var = tk.StringVar()
        self.status_combobox = ttk.Combobox(input_frame, textvariable=self.status_var, values=["Do Zrobienia", "W trakcie", "Zakończone"], state="readonly", font=font)
        self.status_combobox.grid(row=2, column=1, pady=5, padx=10)
        self.status_combobox.current(0)
        button_frame = tk.Frame(input_frame)
        button_frame.grid(row=3, column=1, pady=10, sticky=tk.E)
        self.add_button = tk.Button(button_frame, text="Dodaj zadanie", command=self.add_task, width=15, bg="lightgreen", font=font)
        self.add_button.pack(side=tk.LEFT, padx=5)
        self.update_button = tk.Button(button_frame, text="Aktualizuj Zadanie", width=15, bg="lightblue",
        font=font, state=tk.DISABLED, command=self.update_task)
        self.update_button.pack(side=tk.LEFT, padx=5)
        self.clear_button = tk.Button(button_frame, text="Wyczyść Pola",
        width=15, bg="lightcoral", font=font)
        self.clear_button.pack(side=tk.LEFT, padx=5)
        list_frame = tk.Frame(self.root, padx=10, pady=10)
        list_frame.pack(fill=tk.BOTH, expand = True)
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill = tk.Y)

        headers = {
            "ID": "ID",
            "Title": "Tytuł Zadania",
            "Description": "Opis Zadania",
            "Status": "Status"
        }
        self.tree = ttk.Treeview(list_frame, columns=tuple(headers.keys()), show="headings", yscrollcommand=scrollbar.set)

        self.tree.heading("ID", text="ID")
        self.tree.heading("Title", text="Tytuł Zadania")
        self.tree.heading("Description", text="Opis Zadania")
        self.tree.heading("Status", text="Status")
        self.tree.column("ID", width=50, anchor=tk.CENTER)
        self.tree.column("Title", width=200)
        self.tree.column("Description", width=300)
        self.tree.column("Status", width=100, anchor=tk.CENTER)

        self.tree.pack(fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        action_frame = tk.Frame(self.root, padx=10, pady=10)
        action_frame.pack(fill=tk.X)

        self.delete_button = tk.Button(action_frame,
        text="Usuń Zadanie", width=15, bg="tomato",
        font=font, state=tk.DISABLED, command=self.delete_task)
        self.delete_button.pack(side=tk.LEFT, padx=5)
        self.refresh_button = tk.Button(action_frame,
        text="Odśwież Listę", width=15, bg="lightyellow", font=font, command=self.view_tasks)
        self.refresh_button.pack(side=tk.LEFT, padx=5)
        self.tree.bind("<<TreeviewSelect>>", self.on_tree_select)
        self.view_tasks()

    def on_tree_select(self, event):
        selected_item = self.tree.focus()
        if selected_item:
            values = self.tree.item(selected_item, "values")
            self.title_entry.delete(0, tk.END)
            self.title_entry.insert(0, values[1])
            self.description_entry.delete(0, tk.END)
            self.description_entry.insert(0, values[2])
            self.status_var.set(values[3])
            self.update_button.config(state=tk.NORMAL)
            self.delete_button.config(state=tk.NORMAL)
    
    def update_task(self):
        selected_item = self.tree.focus()
        if not selected_item:
            messagebox.showwarning("Brak Wyboru", "Proszę wybrać zadanie do aktualizacji")
            return
        values = self.tree.item(selected_item, "values")
        task_id = values[0]
        title = self.title_entry.get().strip()
        description = self.description_entry.get().strip()
        status = self.status_var.get()
        if not title:
            messagebox.showwarning("Brak Tytułu", "Proszę wprowadzić tytuł zadania.")
            return
        self.cursor.execute("UPDATE tasks SET title = ?, description = ?, status = ? WHERE id = ?", (title, description, status, task_id))
        self.conn.commit()
        self.view_tasks()
        # self.clear_fields()

    def view_tasks(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.cursor.execute("SELECT * FROM tasks")
        rows = self.cursor.fetchall()
        for row in rows:
            self.tree.insert("", tk.END, values=row)
        self.update_button.config(state=tk.DISABLED)
        self.delete_button.config(state=tk.DISABLED)

    def add_task(self):
        title = self.title_entry.get().strip()
        description = self.description_entry.get().strip()
        status = self.status_var.get()
        if not title:
            messagebox.showwarning("Brak Tytułu",
            "Proszę wprowadzić tytuł zadania.")
            return
        self.cursor.execute(f"INSERT INTO tasks (title, description, status) VALUES (?, ?, ?)", (title, description, status))
        self.conn.commit()
        self.view_tasks()
        # self.clear_fields()

    def delete_task(self):
        selected_item = self.tree.focus()
        if not selected_item:
            messagebox.showwarning("Brak Wyboru", "Proszę wybrać zadanie do usunięcia.")
            return
        values = self.tree.item(selected_item, "values")
        task_id = values[0]
        confirm = messagebox.askyesno("Potwierdzenie", "Czy na pewno chcesz usunąć to zadanie?")
        if confirm:
            self.cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id))
            self.conn.commit()
            self.view_tasks()
            # self.clear_fields()

    def clear_fields(self):
        self.title_entry.delete(0, tk.END)
        self.description_entry.delete(0, tk.END)
        self.status_var.set("Do Zrobienia")
        self.update_button.config(State=tk.DISABLED)
        self.delete_button.config(state=tk.DISABLED)

    def __del__(self):
        self.conn.close()

def main():
    root = tk.Tk()
    app = TaskManager(root)
    root.mainloop()
if __name__ == "__main__":
    main()

