import tkinter as tk
from tkinter import ttk
from random import randint

class App:
    def __init__(self, root):
        self.root = root
        self.width = 730
        self.height = 340
        self.root.geometry(f"{self.width}x{self.height}")
        self.root.resizable(False, False)
        self.backgroundColor = "#B0C4DE"
        self.root.config(background=self.backgroundColor)
        self.InitializeElements()

    def InitializeElements(self):
        self.InitializeDataElements()
        self.InitializeGeneratorElements()

    def InitializeDataElements(self):
        font = ("Arial", 12)

        dataFrame = tk.LabelFrame(self.root, background=self.backgroundColor,
                      text="Dane pracownika", font=font,
                      height=self.height - 100,
                      width=(self.width/2) - 50)
        dataFrame.grid_propagate(0)
        dataFrame.columnconfigure(1, weight=1)

        self.jobPositionVariable = tk.StringVar()

        self.dataInputs = [
            ("Imię", tk.Entry(dataFrame)),
            ("Nazwisko", tk.Entry(dataFrame)),
            ("Stanowisko", ttk.Combobox(dataFrame, values=("Kierownik", "Starszy programista", "Młodszy programista", "Tester"), state="readonly"))
        ]
        i = 0
        for (name, inputField) in self.dataInputs:
            tk.Label(dataFrame, text=name, font=font, background=self.backgroundColor, 
                     justify=tk.LEFT, anchor=tk.W).grid(
                        row=i, column=0, 
                        sticky=tk.EW, padx=20, pady=10)

            inputField.grid(row=i, column=1, sticky=tk.EW, padx=20, pady=10)
            i+=1

        def OnConfirmButtonPressed():
            pass

        tk.Button(root, text="Zatwierdź", width=30,
                  background="#4682B4", font=font, foreground="#FFFFFF",
                  command=OnConfirmButtonPressed).grid(column=0, row=1, columnspan=2)

        dataFrame.grid(column=0, row=0, padx=25, pady=25)
        
    def InitializeGeneratorElements(self):
        font = ("Arial", 12)

        generatorFrame = tk.LabelFrame(self.root, background=self.backgroundColor,
                      text="Generowanie hasła", font=font,
                      height=self.height - 100,
                      width=(self.width/2) - 50)
        generatorFrame.grid_propagate(0)
        generatorFrame.columnconfigure(1, weight=1)

        self.characterCount = tk.StringVar(generatorFrame)
        tk.Entry(generatorFrame, textvariable=self.characterCount).grid(row=0, column=1)
        tk.Label(generatorFrame, text="Ile znaków?",
                 font=font, background=self.backgroundColor,
                 padx=20, pady=10,
                 ).grid(row=0, column=0)

        self.generatorOptions = [
            ("Małe i wielkie litery", tk.BooleanVar(generatorFrame, True)),
            ("Cyfry", tk.BooleanVar(generatorFrame, False)),
            ("Znaki specjalne", tk.BooleanVar(generatorFrame, False))
        ]
        i = 1
        for (name, boolVar) in self.generatorOptions:
            tk.Checkbutton(generatorFrame, font=font,
                           background=self.backgroundColor,
                           justify=tk.LEFT, padx=20, pady=5,
                           text=name, variable=boolVar).grid(column=0, row=i, columnspan=2, sticky=tk.W)
            i += 1
        
        generatorFrame.grid(column=1, row=0, padx=25, pady=25)

    def generate_password(self):
        smallChars = "abcdefghijklmnoprstuvwxyz"
        specialChars = "!@#$%^&*()_+-="

        password = ''
        if (self.generatorOptions[0][1].get()):
            password = specialChars[randint(0, len(specialChars) - 1)]
        if (self.generatorOptions[1][1].get()):
            password = password + smallChars[randint(0, len(specialChars) - 1)].upper()
        
    
if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()