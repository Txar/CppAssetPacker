import socket
import tkinter as tk

root = tk.Tk()

textBoxLeft = tk.Text(root, height=6, width=30, padx=5, pady=5,
                font="Times 16 bold")

textBoxRight = tk.Text(root, height=6, width=30, padx=5, pady=5,
                font="Times 16 bold")

textBoxLeft.pack(side=tk.LEFT)
textBoxRight.pack(side=tk.LEFT)

#choice = int(input("Host - 0, connect - 1: "))
connectionIP = input("What's the IP of the other machine?")
PORT = 42070
isServer = False
#if (choice == 0):
#    isServer = True

#Wait for connection
#if (isServer):
serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serversocket.connect((socket.gethostname(), 42069))
(clientsocket, address) = serversocket.accept()
if str(address) != connectionIP:
    quit()

def send(text):
    clientsocket.send(text.encode())

def receive(sock):
    return sock.recv(1024).decode()

def sync():
    send(textBoxLeft.get())
    textBoxRight.delete(1.0, tk.END)
    textBoxRight.insert(tk.END, receive(serversocket))
    root.after(100, sync)

root.after(100, sync)
root.mainloop()