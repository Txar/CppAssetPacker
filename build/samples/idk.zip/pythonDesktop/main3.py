import tkinter as tk
window = tk.Tk()

def moveRight():
    x = window.winfo_x() + 200
    y = window.winfo_y()
    window.geometry(f"+{x}+{y}")

def moveLeft():
    x = window.winfo_x() - 200
    y = window.winfo_y()
    window.geometry(f"+{x}+{y}")

label1 = tk.Label(window, text="Label 1", bg="red")
label1.pack(side=tk.TOP, expand=True, fill=tk.BOTH)
label2 = tk.Label(window, text="Label 2", bg="silver")
label2.pack(side=tk.BOTTOM, expand=True, fill=tk.BOTH)
button1 = tk.Button(window, bg="red",  text="button 1", command=moveLeft)
button1.pack(side=tk.LEFT, expand=False, fill=tk.BOTH)
button2 = tk.Button(window, bg="yellow", text="button 2", command=moveRight)
button2.pack(side=tk.RIGHT, expand=True, fill=tk.Y)
window.mainloop()