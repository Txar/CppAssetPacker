import tkinter as tk

window = tk.Tk()

tk.Label(
    window,
    text="Wprowadź informacje do nowego opowiadania",
    justify="left"
).pack(anchor="w")

inputTab = tk.Frame(window)

tk.Label(
    inputTab,
    text="Osoba:",
    justify="left"
).grid(row=0, column=0, sticky="w")

tk.Label(
    inputTab,
    text="Rzeczownik w liczbie mnogiej:",
    justify="left"
).grid(row=1, column=0, sticky="w")

tk.Label(
    inputTab,
    text="Czasownik:",
    justify="left"
).grid(row=2, column=0, sticky="w")

tk.Label(
    inputTab,
    text="Przymiotnik(i):",
    justify="left"
).grid(row=3, column=0, sticky="w")

tk.Label(
    inputTab,
    text="Część ciała:",
    justify="left"
).grid(row=4, column=0, sticky="w")

nameValue = tk.StringVar()
nameValue.set("Jan")
tk.Entry(
    inputTab,
    textvariable=nameValue
).grid(row=0, column=1)

pluralNounValue = tk.StringVar()
pluralNounValue.set("dynie")
tk.Entry(
    inputTab,
    textvariable=pluralNounValue
).grid(row=1, column=1)

verbValue = tk.StringVar()
verbValue.set("szukać")
tk.Entry(
    inputTab,
    textvariable=verbValue
).grid(row=2, column=1)

adjectives = [tk.BooleanVar(), tk.BooleanVar(), tk.BooleanVar()]
adjectiveNames = ["naglące", "radosne", "elektryzujące"]

for i in range(3):
    tk.Checkbutton(
        inputTab,
        text=adjectiveNames[i],
        variable=adjectives[i]
    ).grid(row=3, column=i+1)

bodyPart = tk.IntVar()
bodyPartNames = ["pępek", "duży palec u nogi", "rdzeń przedłużony"]
for i in range(3):
    tk.Radiobutton(
        inputTab,
        text=bodyPartNames[i],
        variable=bodyPart,
        value=i
    ).grid(row=4, column=i+1)

inputTab.pack(anchor="w")

def adjFormat(s : str, isFirst = False):
    if isFirst:
        s = s[0].upper() + s[1:]
    s += ", "
    return s

output = tk.Text(
    window,
    height=15,
    wrap=tk.WORD
)

def generate():
    adjs = ""
    isFirst = True
    for i in range(3):
        if (adjectives[i].get()):
            adjs += adjFormat(adjectiveNames[i], isFirst)
            if isFirst == True: isFirst = False
    toGenerate = f"Sławny badacz i odkrywca {nameValue.get()} o mało co nie zrezygnował z życiowej misji poszukiwania zaginionego miasta, które zamieszkiwały {pluralNounValue.get()}, gdy pewnego dnia {pluralNounValue.get()} znalazły {nameValue.get()}a. {adjs}osobliwe uczucie owładnęło badaczem. Po tak długim czasie poszukiwanie wreszcie się zakończyło. W oku {nameValue.get()}a pojawiła się łza, która spadła na jego {bodyPartNames[bodyPart.get()]}. A wtedy {pluralNounValue.get()} szybko pożarły {nameValue.get()}a. Jaki morał płynie z tego opowiadania? Pomyśl, zanim zaczniesz coś {verbValue.get()}."
    output.delete(1.0, tk.END)
    output.insert(tk.END, toGenerate)
    

tk.Button(
    window,
    text="Kliknij, aby wyświetlić opowiadanie",
    command=generate
).pack(anchor="w")

output.pack()

window.mainloop()