import tkinter as tk
window = tk.Tk()

buttonsFrame = tk.Frame(
    window
)

textVariable = tk.StringVar()

display = tk.Entry(
    window,
    textvariable=textVariable,
    width=16,
    font="Serif 30",
    state="readonly"
)

isErrorDisplayed = False
def onButtonPressed(label : str):
    global isErrorDisplayed
    match (label):
        case "Clear":
            textVariable.set("")
        case "=":
            try:
                textVariable.set(eval(textVariable.get()))
            except:
                isErrorDisplayed = True
                textVariable.set("ERR")
        case _:
            if isErrorDisplayed: textVariable.set("")
            isErrorDisplayed = False
            textVariable.set(textVariable.get() + label)

        

def caller(method, arg):
    return lambda : method(arg)

buttonsTexts = ["7", "8", "9", "+", "4", "5", "6", "-", "1", "2", "3", "*", "0", "Clear", "=", "/"]
buttons = [tk.Button(buttonsFrame, text=i, command=caller(onButtonPressed, i), width=8, height=4, font="Serif 15") for i in buttonsTexts]

columns = 4
rows = 4
row, col = 0, 0
for i in buttons:
    if col == columns:
        col = 0
        row += 1
    if row == rows:
        break
    i.grid(row=row, column=col, sticky=tk.EW)
    col += 1

display.pack(padx=10, pady=10)
buttonsFrame.pack()

window.mainloop()