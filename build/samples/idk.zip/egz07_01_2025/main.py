import tkinter as tk
from tkinter import messagebox

class App:
    def __init__(self, root):
        root.title("Wprowadzenie danych do paszportu. Wykonał: Maksymilian Chojnacki")
        self.root = root
        self.width = 840
        self.height = 340
        self.root.geometry(f"{self.width}x{self.height}")
        self.root.resizable(False, False)
        self.backgroundColor = "#5F9EA0"
        self.root.config(background=self.backgroundColor)
        self.InitializeImages()
        self.InitializeElements()

    def InitializeImages(self):
        assetGen = [(f"{i}-odcisk", (175, 225)) for i in ["000", "111", "333"]] + [(f"{i}-zdjecie", (175, 225)) for i in ["000", "111", "333"]]
        assets = {}

        for (name, size) in assetGen:
            img = tk.PhotoImage(file=name+".png", width=size[0], height=size[1])
            assets[name] = img

        self.assets = assets

    def InitializeElements(self):
        self.InitializeLeftPlane()
        self.InitializeRightPlane()

    def InitializeLeftPlane(self):
        font = ("Arial", 12)

        leftFrame = tk.Frame(self.root, background=self.backgroundColor,
                             height=self.height - 20, 
                             width=(self.width/2) - 50)

        dataFrame = tk.LabelFrame(leftFrame, background=self.backgroundColor,
                      text="Kolor oczu", font=font, width=(self.width/2)-60)
                      
        #dataFrame.grid_propagate(0)              
        leftFrame.grid_propagate(0)
        #dataFrame.columnconfigure(1, weight=1)

        self.jobPositionVariable = tk.StringVar()


        self.numVar = tk.StringVar()

        def NumberUpdate(*a):
            v = self.numVar.get()
            if v in ["000", "111", "333"]:
                self.img1.config(image=self.assets[v + "-zdjecie"])
                self.img2.config(image=self.assets[v + "-odcisk"])
                self.img1.grid()
                self.img2.grid()
            else:
                self.img1.grid_remove()
                self.img2.grid_remove()

        self.numVar.trace("w", NumberUpdate)

        self.dataInputs = [
            ("Numer", tk.Entry(leftFrame, textvariable=self.numVar)),
            ("Imię", tk.Entry(leftFrame)),
            ("Nazwisko", tk.Entry(leftFrame))
        ]
        i = 0
        for (name, inputField) in self.dataInputs:
            tk.Label(leftFrame, text=name, font=font, background=self.backgroundColor, 
                     justify=tk.LEFT, anchor=tk.W).grid(
                        row=i, column=0,
                        sticky=tk.EW, padx=20, pady=10)

            inputField.grid(row=i, column=1, sticky=tk.EW, padx=20, pady=10)
            i+=1

        self.eyeColor = tk.IntVar()

        self.eyeColors = [
            (0, "niebieskie"),
            (1, "zielone"),
            (2, "piwne")
        ]
        
        i = 0
        for (value, text) in self.eyeColors:
            tk.Radiobutton(dataFrame, variable=self.eyeColor, background=self.backgroundColor, 
                    value=value, text=text).grid(row=i, column=0, sticky=tk.W, padx=20, pady=5)
            i+=1

        dataFrame.grid(column=0, row=3, columnspan=2, padx=25, pady=25, sticky=tk.EW)
        leftFrame.grid(column=0, row=0, padx=25, pady=25)
        
    def InitializeRightPlane(self):
        font = ("Arial", 12)

        rightPlane = tk.Frame(self.root, background=self.backgroundColor,
                      height=self.height - 100,
                      width=(self.width/2) - 50)

        rightPlane.propagate(0)

        def OnConfirmButtonPressed():
            messagebox.showinfo(message=f"{self.dataInputs[1][1].get()} {self.dataInputs[2][1].get()} kolor oczu {self.eyeColors[self.eyeColor.get()][1]}", title=" ")

        self.img1 = tk.Label(rightPlane, image=self.assets["111-zdjecie"])
        self.img1.grid(column=0, row=0, padx=10, pady=10)
        self.img1.grid_remove()

        self.img2 = tk.Label(rightPlane, image=self.assets["111-odcisk"])
        self.img2.grid(column=1, row=0, padx=10, pady=10)
        self.img2.grid_remove()

        tk.Button(rightPlane, text="OK", width=30,
                  background="#F0FFFF", font=font,
                  command=OnConfirmButtonPressed).grid(column=0, row=1, columnspan=2)
        
        rightPlane.grid(column=1, row=0, padx=25, pady=25)
        
    
if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()