"""
def czy_przestepny(rok):
    if rok % 4:
        return False
    if not rok % 100:
        return not rok % 400
    return True

def dni_w_miesiacu(rok, miesiac):
    a = [31, 28 + czy_przestepny(rok), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return a[miesiac - 1]

testuj_lata = [1900, 2000, 2016, 1987]
testuj_miesiace = [2, 2, 1, 11]
testuj_wynik = [28, 29, 31, 30]
for i in range(len(testuj_lata)):
	r = testuj_lata[i]
	m = testuj_miesiace[i]
	print(r, m, "-> ", end="")
	wynik = dni_w_miesiacu(r, m)
	if wynik == testuj_wynik[i]:
		print("OK")
	else:
		print("Nie powiodło się")


"""
"""
def czy_przestepny(rok):
    if rok % 4:
        return False
    if not rok % 100:
        return not rok % 400
    return True

def dni_w_miesiacu(rok, miesiac):
    a = [31, 28 + czy_przestepny(rok), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return a[miesiac - 1]

def dzien_w_roku(rok, miesiac, dzien):
    suma = 0
    for i in range(1, miesiac):
        suma += dni_w_miesiacu(rok, i)
    return suma + dzien

print(dzien_w_roku(2000, 12, 31))

import math
def czy_pierwsza(liczba):
    for i in range(2, math.floor(math.sqrt(liczba) + 1)):
        if not liczba % i: return False
    return True

for i in range(1, 20):
	if czy_pierwsza(i + 1):
			print(i + 1, end=" ")
print()

"""