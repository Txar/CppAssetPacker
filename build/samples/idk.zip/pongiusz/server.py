import random, socket
from pygame import time
from pongiusz_events import *

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

def initConnection():
    sock.bind((HOST, SERVER_PORT))
    player1_addr = ''
    player2_addr = ''
    while True:
        (data, addr) = getConnectionSocket(sock)
        if data:
            if int(str(data)) == GREET:
                if player1_addr == '': player1_addr = addr
                else: 
                    player2_addr = addr
                    break

def getConnectionSocket(sock):
    return sock.recvfrom(4)

def sendData(addr, data):
    sock.sendto(bytes(data), (addr, CLIENT_PORT))


player2_points, player_points = 0, 0

SCREEN_SIZE = [200*1, 250*1]

max_ball_speed = 10

speed_multiplier = 1

distance_from_border = 45

player_size = [45, 4]
player_x = (SCREEN_SIZE[0] - player_size[0]) / 2
player2_x = (SCREEN_SIZE[0] - player_size[0]) / 2

player_speed = 3

ball_freeze_frames = 30
ball_size = 5
ball_direction = [1, 1]
ball_x = (SCREEN_SIZE[0] - ball_size) / 2
ball_y = (SCREEN_SIZE[1] - ball_size) / 2
ball_speed = 5
running = True

def resetBall():
    global ball_direction, ball_x, ball_y, ball_freeze_frames, computer_points
    ball_direction = [0, random.choice([-1, 1])]
    ball_x = (SCREEN_SIZE[0] - ball_size) / 2
    ball_y = (SCREEN_SIZE[1] - ball_size) / 2
    ball_freeze_frames = 30

resetBall()

def loop():
    if ball_freeze_frames == 0:
        ball_x += ball_direction[0] * ball_speed
        ball_y += ball_direction[1] * ball_speed
    else:
        ball_freeze_frames -= 1

    if ball_x > SCREEN_SIZE[0]:
        ball_direction[0] = ball_direction[0] * -1
    if ball_x < 0:
        ball_direction[0] = ball_direction[0] * -1

    if ball_y > SCREEN_SIZE[1]:
        resetBall()
        player2_points += 1
    if ball_y < 0:
        resetBall()
        player_points += 1

    if ball_y >= SCREEN_SIZE[1] - distance_from_border and ball_y <= SCREEN_SIZE[1] - distance_from_border + player_size[1]:
        if ball_x >= player_x - player_size[0] / 10 and ball_x <= player_x + player_size[0] + player_size[0] / 10:
            ball_direction[1] = -ball_direction[1]
            if abs(ball_direction[0]) <= max_ball_speed:
                ball_direction[0] += player_velocity * 0.1 * speed_multiplier

    if ball_y <= distance_from_border + player_size[1] and ball_y >= distance_from_border:
        if ball_x >= player2_x - player_size[0] / 10 and ball_x <= player2_x + player_size[0] + player_size[0] / 10:
            ball_direction[1] = -ball_direction[1]
            if abs(ball_direction[0]) <= max_ball_speed:
                ball_direction[0] += player2_velocity * 0.1 * speed_multiplier

    player2_velocity = 0
    player_velocity = 0