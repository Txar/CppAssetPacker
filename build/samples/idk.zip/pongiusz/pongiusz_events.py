from enum import Enum

#class Events(Enum):
MOVE_LEFT = 0
MOVE_RIGHT = 1
GREET = 2

HOST = '127.0.0.1'
CLIENT_PORT = 7681
SERVER_PORT = 7682