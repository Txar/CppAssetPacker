import pygame, random, math, os
import socket
from copy import copy

"""
global conn, addr, server, sock
global HOST, PORT

isServer = input("server, client: ")
if isServer == "server":
     server = True
elif isServer == "client":
     server = False

if server:
    #HOST = socket.gethostbyname(socket.gethostname())
    HOST = '192.168.131.102'
    print(socket.gethostbyname(socket.gethostname()))
    PORT = 7681
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)   
    sock.bind((HOST, PORT))
    sock.listen()
    conn, addr = sock.accept()
    print(f"Client {addr} connected!")

else:
    HOST = input("server ip: ")
    PORT = 1234
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((HOST, PORT))
"""

HOST = '127.0.0.1'
PORT = 7681
print(socket.gethostbyname(socket.gethostname()))
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((HOST, PORT))

def getConnectionSocket(sock):
    sock.listen()
    return sock.recvfrom(4)


def roundTo(x, base=32):
    return int(base * round(float(x) / base))

SCREEN_SIZE = [200*1, 250*1]

screen = pygame.display.set_mode(SCREEN_SIZE, pygame.RESIZABLE)

TEXT_COLOR = (60, 150, 220)

BACKGROUND_COLOR = (60, 150, 220)

STRIPE_COLOR = (30, 75, 110)

BALL_COLOR = (255, 255, 255)

CHEAT_COLOR = (150, 150, 150)

max_ball_speed = 10

speed_multiplier = 1

distance_from_border = 45

player_size = [45, 4]
player_x = (SCREEN_SIZE[0] - player_size[0]) / 2
player2_x = (SCREEN_SIZE[0] - player_size[0]) / 2

player_speed = 3

ball_size = 5
ball_direction = [1, 1]
ball_x = (SCREEN_SIZE[0] - ball_size) / 2
ball_y = (SCREEN_SIZE[1] - ball_size) / 2

ball_speed = 5

clock = pygame.time.Clock()

player_points = 0
computer_points = 0

player_velocity = 0
player2_velocity = 0

FPS = 60

ball_freeze_frames = 30

ball_hit_point = SCREEN_SIZE[0] / 2

change = 3

cheat_surf = pygame.Surface(SCREEN_SIZE, pygame.SRCALPHA, 32)

def calculateBallHitPoint():
    global ball_y, ball_x, distance_from_border, SCREEN_SIZE, ball_direction, ball_speed
    tempBallY = copy(ball_y)
    tempBallX = copy(ball_x)
    tempBallDirection = copy(ball_direction)

    if ball_y < (4/5) * SCREEN_SIZE[1] and ball_direction[1] < 0:

        while tempBallY > distance_from_border:

            if tempBallX > SCREEN_SIZE[0]:
                tempBallDirection[0] = tempBallDirection[0] * -1
            elif tempBallX < 0:
                tempBallDirection[0] = tempBallDirection[0] * -1

            tempBallY += tempBallDirection[1] * ball_speed
            tempBallX += tempBallDirection[0] * ball_speed

        return tempBallX
    else:
        return SCREEN_SIZE[0] / 2

def getCheatSurface():
    global ball_y, ball_x, distance_from_border, SCREEN_SIZE, ball_direction, ball_speed, max_ball_speed, speed_multiplier, player2_velocity

    tempBallY = copy(ball_y)
    tempBallX = copy(ball_x)
    tempBallDirection = copy(ball_direction)

    surf = pygame.Surface(SCREEN_SIZE, pygame.SRCALPHA, 32)

    #if ball_y > (1/3) * SCREEN_SIZE[1] and ball_direction[1] > 0:
    i = 0
    while tempBallY < SCREEN_SIZE[1] - distance_from_border:
        if tempBallX > SCREEN_SIZE[0]:
            tempBallDirection[0] = tempBallDirection[0] * -1
        elif tempBallX < 0:
            tempBallDirection[0] = tempBallDirection[0] * -1
        if tempBallY < distance_from_border:
            tempBallDirection[1] = tempBallDirection[1] * -1
            if abs(tempBallDirection[0]) <= max_ball_speed:
                tempBallDirection[0] += player2_velocity * 0.1 * speed_multiplier

        pygame.draw.rect(surf, CHEAT_COLOR, (tempBallX - ball_size / 2, tempBallY - ball_size / 2, ball_size, ball_size), 75)        
        tempBallY += tempBallDirection[1] * ball_speed
        tempBallX += tempBallDirection[0] * ball_speed

        if (i > 500):
            return pygame.Surface(SCREEN_SIZE, pygame.SRCALPHA, 32)
        i+=1

    return surf
    #else:
    #    return surf

def resetBall():
    global ball_direction, ball_x, ball_y, ball_freeze_frames, computer_points
    ball_direction = [0, random.choice([-1, 1])]
    ball_x = (SCREEN_SIZE[0] - ball_size) / 2
    ball_y = (SCREEN_SIZE[1] - ball_size) / 2
    ball_freeze_frames = 30

resetBall()

pygame.init()
pygame.font.init()

fontObj = pygame.font.SysFont("Helvetica-Bold.ttf", int(SCREEN_SIZE[1]/5))

opponent_freeze_frames = 0

running = True
while running:
    SCREEN_SIZE = list(screen.get_size())

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill(BACKGROUND_COLOR)

    computer_points_surf = fontObj.render(str(computer_points), True, TEXT_COLOR)
    player_points_surf = fontObj.render(str(player_points), True, TEXT_COLOR)

    pygame.draw.rect(screen, STRIPE_COLOR, (0, (SCREEN_SIZE[1] / 2) - SCREEN_SIZE[1]/5, SCREEN_SIZE[0], SCREEN_SIZE[1]/2.5))

    screen.blit(computer_points_surf, ((SCREEN_SIZE[0] - computer_points_surf.get_size()[0])/2, SCREEN_SIZE[1]/2 - computer_points_surf.get_size()[1]))
    screen.blit(player_points_surf, ((SCREEN_SIZE[0] - player_points_surf.get_size()[0])/2, SCREEN_SIZE[1]/2))

    pygame.draw.rect(screen, (255, 255, 255), (player_x, SCREEN_SIZE[1] - distance_from_border, player_size[0], player_size[1]))
    pygame.draw.rect(screen, (255, 255, 255), (player2_x, distance_from_border, player_size[0], player_size[1]))

    screen.blit(cheat_surf, (0, 0))
    pygame.draw.rect(screen, BALL_COLOR, (ball_x - ball_size / 2, ball_y - ball_size / 2, ball_size, ball_size), 75)

    pygame.display.flip()

    if ball_freeze_frames == 0:
        ball_x += ball_direction[0] * ball_speed
        ball_y += ball_direction[1] * ball_speed
    else:
        ball_freeze_frames -= 1


    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT]:
        if player_x - player_speed >= 0:
            player_x -= player_speed
            player_velocity = -player_speed
    if keys[pygame.K_RIGHT]:
        if player_x + player_size[0] + player_speed <= SCREEN_SIZE[0]:
            player_x += player_speed
            player_velocity = player_speed

    if keys[pygame.K_UP]:
        SCREEN_SIZE[1] += 10
        screen = pygame.display.set_mode(SCREEN_SIZE, pygame.RESIZABLE)

    if keys[pygame.K_DOWN]:
        SCREEN_SIZE[1] -= 10
        SCREEN_SIZE[1] = abs(SCREEN_SIZE[1])
        screen = pygame.display.set_mode(SCREEN_SIZE, pygame.RESIZABLE)

    if keys[pygame.K_x]:
        SCREEN_SIZE[0] += 10
        screen = pygame.display.set_mode(SCREEN_SIZE, pygame.RESIZABLE)

    if keys[pygame.K_z]:
        SCREEN_SIZE[0] -= 10
        SCREEN_SIZE[0] = abs(SCREEN_SIZE[0])
        screen = pygame.display.set_mode(SCREEN_SIZE, pygame.RESIZABLE)
        
    if keys[pygame.K_SPACE]:
        ball_freeze_frames += 1
        opponent_freeze_frames += 1

    if keys[pygame.K_ESCAPE]:
        running = False

    if ball_x > SCREEN_SIZE[0]:
        ball_direction[0] = ball_direction[0] * -1
    if ball_x < 0:
        ball_direction[0] = ball_direction[0] * -1

    if ball_y > SCREEN_SIZE[1]:
        resetBall()
        computer_points += 1
    if ball_y < 0:
        resetBall()
        player_points += 1

    if ball_y >= SCREEN_SIZE[1] - distance_from_border and ball_y <= SCREEN_SIZE[1] - distance_from_border + player_size[1]:
        if ball_x >= player_x - player_size[0] / 10 and ball_x <= player_x + player_size[0] + player_size[0] / 10:
            #if ball_x <= player_x + (player_size[0] / 6) or ball_x >= player_x + player_size[0] - (player_size[0] / 6):
            #    ball_direction[0] = ball_direction[0] * -1
            #else:
            ball_direction[1] = -ball_direction[1]
            if abs(ball_direction[0]) <= max_ball_speed:
                ball_direction[0] += player_velocity * 0.1 * speed_multiplier

    if ball_y <= distance_from_border + player_size[1] and ball_y >= distance_from_border:
        if ball_x >= player2_x - player_size[0] / 10 and ball_x <= player2_x + player_size[0] + player_size[0] / 10:
            #if ball_x <= player_x + (player_size[0] / 6) or ball_x >= player_x + player_size[0] - (player_size[0] / 6):
            #    ball_direction[0] = ball_direction[0] * -1
            #else:
            ball_direction[1] = -ball_direction[1]
            if abs(ball_direction[0]) <= max_ball_speed:
                ball_direction[0] += player2_velocity * 0.1 * speed_multiplier

    player2_velocity = 0
    player_velocity = 0

    if ball_y < SCREEN_SIZE[1] * (1 / 1.5) and opponent_freeze_frames == 0:
        ball_hit_point = roundTo(calculateBallHitPoint(), player_speed*2)

        if ball_hit_point > player2_x + player_size[0] / 4:
            if player2_x + player_speed + player_size[0] <= SCREEN_SIZE[0]:
                player2_x += player_speed
                player2_velocity = player_speed

        if ball_hit_point < player2_x + player_size[0] * (3 / 4):
            if player2_x - player_speed >= 0:
                player2_x -= player_speed
                player2_velocity = -player_speed
    elif opponent_freeze_frames > 0:
        opponent_freeze_frames -= 1

    if 0 == 1 and ball_y < SCREEN_SIZE[1] * (2 / 3):

        if ball_x > player2_x + player_size[0] / 4:
            if player2_x + player_speed + player_size[0] <= SCREEN_SIZE[0]:
                player2_x += player_speed
                player2_velocity = player_speed

        if ball_x < player2_x + player_size[0] * (3 / 4):
            if player2_x - player_speed >= 0:
                player2_x -= player_speed
                player2_velocity = -player_speed
    
    """g += change
    if g in [30, 120]:
        change = -change
    player_size[0] = g"""
    cheat_surf = getCheatSurface()

    clock.tick(FPS)
pygame.quit()