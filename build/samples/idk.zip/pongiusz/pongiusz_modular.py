import client
import server
import pygame

clock = pygame.time.Clock()
FPS = 60

running = True
while running:
    client.loop()
    server.loop()
    clock.tick(FPS)
pygame.quit()