import pongul, pygame

FPS = 60
game = pongul.Game(True)
clock = pygame.time.Clock()
while game.loop():
    clock.tick(FPS)