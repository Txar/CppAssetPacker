import socket

class Server:
    def pollEvents():
        return []