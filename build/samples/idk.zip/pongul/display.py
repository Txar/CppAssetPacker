import pygame

TEXT_COLOR = (60, 150, 220)
BACKGROUND_COLOR = (60, 150, 220)
STRIPE_COLOR = (30, 75, 110)
BALL_COLOR = (255, 255, 255)
CHEAT_COLOR = (150, 150, 150)

class Display:
    def __init__(self, SCREEN_SIZE):
        pygame.init()
        self.SCREEN_SIZE = SCREEN_SIZE
        self.screen = pygame.display.set_mode(SCREEN_SIZE, pygame.RESIZABLE)
        self.fontobj = pygame.font.SysFont("Helvetica-Bold.ttf", int(SCREEN_SIZE[1]/5))

    def loop(self, game):
        self.screen.fill(BACKGROUND_COLOR)

        game.player2_points_surf = self.fontobj.render(str(game.player2_points), True, TEXT_COLOR)
        game.player_points_surf = self.fontobj.render(str(game.player_points), True, TEXT_COLOR)

        pygame.draw.rect(self.screen, STRIPE_COLOR, (0, (self.SCREEN_SIZE[1] / 2) - self.SCREEN_SIZE[1]/5, self.SCREEN_SIZE[0], self.SCREEN_SIZE[1]/2.5))

        self.screen.blit(game.player2_points_surf, ((self.SCREEN_SIZE[0] - game.player2_points_surf.get_size()[0])/2, self.SCREEN_SIZE[1]/2 - game.player2_points_surf.get_size()[1]))
        self.screen.blit(game.player_points_surf, ((self.SCREEN_SIZE[0] - game.player_points_surf.get_size()[0])/2, self.SCREEN_SIZE[1]/2))

        pygame.draw.rect(self.screen, (255, 255, 255), (game.player_x, self.SCREEN_SIZE[1] - game.distance_from_border, game.player_size[0], game.player_size[1]))
        pygame.draw.rect(self.screen, (255, 255, 255), (game.player2_x, game.distance_from_border, game.player_size[0], game.player_size[1]))

        #self.screen.blit(cheat_surf, (0, 0))
        pygame.draw.rect(self.screen, BALL_COLOR, (game.ball_x - game.ball_size / 2, game.ball_y - game.ball_size / 2, game.ball_size, game.ball_size), 75)

        pygame.display.flip()

    def pollEvents():
        events = []
        for event in pygame.event.get():
            events.append((0, event))
        