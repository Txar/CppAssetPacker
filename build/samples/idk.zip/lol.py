[print(i) for i in range(0, 15)]
