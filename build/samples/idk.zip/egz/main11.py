from random import randint

def getDiceCount():
    count = 0
    while count not in range(3, 11):
        count = int(input("Ile kostek chcesz rzucić?(3 - 10)\n"))
    return count

def rollDice(count):
    return [randint(1, 6) for _ in range(count)]

def countPoints(diceList):
    points = 0
    appearedCounts = [0 for _ in range(6)]
    for i in diceList:
        if appearedCounts[i - 1] == 1:
            points += i*2
        if appearedCounts[i - 1] > 2:
            points += i
        appearedCounts[i - 1] += 1
    return points


count = getDiceCount()
while True:
    dice = rollDice(count)
    for i in range(len(dice)):
        print(f"Kostka {i + 1}: {dice[i]}")
    points = countPoints(dice)
    print(f"Liczba uzyskanych punktów: {points}")
    if input("Jeszcze raz? (t/n)\n") == "n": break