class film:
    def __init__(self):
        self._tytul = ""
        self._liczbaWypozyczen = 0

    def ustawTytul(self, tytul):
        self._tytul = tytul
    
    def pobierzTytul(self):
        return self._tytul

    def pobierzLiczbeWypozyczen(self):
        return self._liczbaWypozyczen

    def inkrementujLiczbeWypozyczen(self):
        self._liczbaWypozyczen += 1

titanic = film()
print(titanic.pobierzLiczbeWypozyczen())
print(titanic.pobierzTytul())

try:
    titanic.ustawTytul("Titanic")
    assert titanic.pobierzTytul() == "Titanic"
    print(titanic.pobierzTytul())
    print(titanic.pobierzLiczbeWypozyczen())
    titanic.inkrementujLiczbeWypozyczen()
    print(titanic.pobierzLiczbeWypozyczen())
    titanic.inkrementujLiczbeWypozyczen()
    print(titanic.pobierzLiczbeWypozyczen())
    print("Testy zakończone powodzeniem!")
except:
    print("Testy zakończone niepowodzeniem.")