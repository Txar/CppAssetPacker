import random

def generate(n):
    return [random.randint(1, 100) for _ in range(n)]

def find(t, x):
    table = [i for i in t]
    table.append(x)
    index = 0
    for i in table:
        if i == x: return index
        index += 1

try:
    n = 7
    table = [5, 10, 20, 30, 55, 23, 0]
    assert find(table, 23) == 5
    assert find(table, 10) == 1
    assert find(table, 3) == n
    print("Testy zakończyły się sukcesem!")
except Exception as e:
    print("Testy zakończyły się niepowodzeniem.")

n = 50

x = int(input("Wprowadź szukaną liczbę: "))

table = generate(n)

print(table)
found = find(table, x)
if (found == n):
    print('Nie znaleziono elementu!')
else:
    print(f'Znaleziono element pod indeksem {found}.')