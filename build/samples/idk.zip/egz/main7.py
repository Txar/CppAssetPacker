class notatka:
    __licznik = 0
    
    def __init__(self, tytul, tresc):
        notatka.__licznik += 1
        self.__identyfikator = notatka.__licznik
        self._tytul = tytul
        self._tresc = tresc

    def wyswietlTytulTresc(self):
        print(self._tytul)
        print(self._tresc)

    def wyswietlDiagnostyczne(self):
        print(
              notatka.__licznik, 
              self.__identyfikator, 
              self._tytul, 
              self._tresc, 
              sep=";"
        )

listaZakupow = notatka("Lista zakupów", "Banany, jabłka, jajka, łosoś")
biologia = notatka("Biologia", "Mitochondria to centrum energetyczne komórki.")

print("Wyświetlanie tytułu i treści notatek:")
listaZakupow.wyswietlTytulTresc()
biologia.wyswietlTytulTresc()

print("Wyświetlanie danych diagnostycznych:")
listaZakupow.wyswietlDiagnostyczne()
biologia.wyswietlDiagnostyczne()
