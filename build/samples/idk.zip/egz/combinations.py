LETTERS = "AĄBCĆDEĘFGHIJKLŁMNŃOÓPRSŚTUVWXYZŹŻ"

with open("slowa.txt", encoding="utf-8") as f:
    for line in f:
        #print(line.strip().upper())
        word2 = line.strip().upper()
        if len(word2) != 5: continue
        for i in LETTERS:
            for j in LETTERS:
                for k in LETTERS:
                    word = f"{i}{j}{k}RA"
                    if word == word2:
                        print(word)
                