#include <stdlib.h>
#include <stdio.h>

typedef int (*myCode)();

int main() {
    int (*myCode_)();
    myCode_ = (myCode)malloc(sizeof(char)*62);
    printf("TEST");
    while (myCode_() != 0) {}
    printf("Success!");
    return 0;
}