from math import sqrt, floor

n = 100

def fill(table, n):
    for _ in range(n + 1):
        table.append(True)

A = []
fill(A, n)
for i in range(2, floor(sqrt(n)) + 1):
    if A[i] == True:
        for j in range(2*i, n + 1, i):
            A[j] = False

print('Liczby pierwsze: ')
for i in range(2, len(A)):
    if A[i]: print(i, end=', ')

#print('\nLiczby pierwsze: ')
#[print(i, end=', ') for i in range(len(A)) if A[i] == True]