class StringTools:
    vowels = "aąeęiouóyAĄEĘIOUÓY"

    @staticmethod
    def countVowels(text : str):
        if text == None:
            return 0

        count = 0
        for i in text: 
            if i in StringTools.vowels: 
                count += 1

        return count

    @staticmethod
    def deleteRepetitions(text: str):
        if text == None: 
            return ""

        prevChar = ""
        newStr = ""
        for i in text:
            if i != prevChar: 
                newStr += i
            prevChar = i

        return newStr

testString = input("Wprowadź łańcuch: ")
print(f"Ilość samogłosek: {StringTools.countVowels(testString)}")
print(f"Łańcuch po usunięciu powtórzeń: {StringTools.deleteRepetitions(testString)}")