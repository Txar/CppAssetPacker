def NWD(a, b):
    while a != b:
        if a > b:
            a = a - b
        else:
            b = b - a
    return a


try:
    a = int(input("Wprowadź a: "))
    b = int(input("Wprowadź b: "))
except BaseException:
    print("Wprowadź poprawne wartości!")
    exit()

print(f"NWD to {NWD(a, b)}")


try:
    assert NWD(5, 10) == 5
    assert NWD(42, 33) == 3
    print("Testy zakończyły się sukcesem.")
except:
    print("Testy zakończonyły się niepowodzeniem.")