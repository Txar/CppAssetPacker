from random import randint

gen = lambda : [randint(0, 100) for _ in range(50)]

def bubbleSort(tab : list):
    for j in range(len(tab) - 1):
        swapped = False
        for i in range(len(tab) - j - 1):
            if tab[i] > tab[i + 1]:
                swapped = True
                tab[i], tab[i + 1] = tab[i + 1], tab[i]        
        #print(tab)
        if not swapped: 
            break

tab = gen()
bubbleSort(tab)
print("Posortowana tablica:")
print(tab)