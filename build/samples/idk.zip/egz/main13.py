from random import randint

def add1(thing):
    thing += 1

class tableSorter:
    def generate(self, n : int = 10, min : int = 1, max : int = 20):
        self._min = min
        self._max = max
        return [randint(min, max) for _ in range(n)]

    def __init__(self, tab = None):
        if (tab == None):
            self.tab = self.generate(10, 1, 20)
        else:
            self.tab = tab

    def sort(self):
        occurrences = [0 for _ in range(self._max + 1)]
        for i in self.tab:
            occurrences[i] += 1

        newTab = []
        for i in range(len(occurrences)):
            for _ in range(occurrences[i]):
                newTab.append(i)
        self.tab = newTab

    def printTab(self):
        index = 0
        for i in self.tab:
            print(i, end="")
            if (index != len(self.tab) - 1): print(", ", end="")
            index += 1
        print()

t = tableSorter()
t.printTab()
t.sort()
t.printTab()