class Osoba:
    licznik = 0

    def kopiuj(self, source):
        self.__id = source.__id
        self.__name = source.__name

    def __init__(self, id = 0, imie = ""):
        self.__id = id
        self.__imie = imie
        licznik += 1

    def przywitaj(self, imie):
        if self.__imie == "": print("Brak danych")
        else: print(f"Cześć {imie}, mam na imię {self.__imie}")