from random import randint

class SortTab:
    def __init__(self, tab):
        self.tab = tab

    def sort(self):
        for i in range(len(self.tab)):
            currentMax = self.__getIndexOfMax(i)
            self.tab[i], self.tab[currentMax] = self.tab[currentMax], self.tab[i]
            print(self.tab)
    
    def __getIndexOfMax(self, initIndex = 0):
        currentMax = None
        for i in range(initIndex, len(self.tab)):
            if currentMax == None or self.tab[currentMax] < self.tab[i]:
                currentMax = i
        return currentMax

print("Wprowadź elementy do posortowania.")
tabToSort = [int(input(f"Element {i}: ")) for i in range(10)]
tableSorter = SortTab(tabToSort)

tableSorter.sort()
print("Posortowana tablica: ")
print(tableSorter.tab)