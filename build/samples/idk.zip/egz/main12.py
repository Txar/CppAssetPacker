class Album:
    def __init__(self, artist : str, name : str, songsNumber : int, year : int, downloadNumber : int):
        self.artist = artist
        self.name = name
        self.songsNumber = songsNumber
        self.year = year
        self.downloadNumber = downloadNumber

    def print(self, f = None):
        print(self.artist, 
              self.name, 
              self.songsNumber, 
              self.year,
              self.downloadNumber,
              sep="\n", file=f)
albums = []

with open("Data.txt", encoding="utf-8") as f:
    counter = 0
    linesForAlbum = []
    for line in f.readlines():
        linesForAlbum.append(line)
        counter += 1
        if counter == 6:
            (artist, name, songsNumber, year, downloadNumber, _) = tuple(linesForAlbum)
            linesForAlbum = []
            counter = 0

            album = Album(artist.strip(), name.strip(), int(songsNumber), int(year), int(downloadNumber))
            album.print()
            print("")
            albums.append(album)

albums.sort(reverse = True, key = lambda a : a.downloadNumber)

with open("Output.txt", "w", encoding="utf-8") as f:
    for i in albums:
        i.print(f)
        print("", file=f)